module.exports = { secretOrKey: "&4ncjsddfdf7wj" };
